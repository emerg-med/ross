/**************************************************************************
Nav99: Configurable Navigation Applet
Author: Joe Flatt, joefl@engr.orst.edu
Copyright (C) 1999, Joe Flatt

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

8/19/99		jlf		Wrote program.
9/9/99		jlf		Added default color selections
9/14/99		jlf		Fixed caching difference between browsers
9/16/99		jlf		Added font parameters

***************************************************************************/


import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.util.StringTokenizer;
import java.net.*;

public class Nav99 extends Applet implements ActionListener, ItemListener {

	String[][] urlArray;
	String[] target;
	Button[] button;
	List[] list;
	Dimension largeButtonSize;
	Component prevList;
	Object prevSource;
	int rows, smallButtonHeight, listHeightSize;
	boolean startSwitch = true;

	public void init() {
		String bcString, fcString, fontName, fontSize, fontStyle;
		Color buttonColor, fontColor;
		int token = 0, fontSizeInt, fontStyleInt;

		rows = Integer.parseInt(getParameter("rows"));
		urlArray = new String[rows][];
		target = new String[rows];
		button = new Button[rows];
		list = new List[rows];

		// set Font
		fontName = getParameter("fontName");
		if (fontName == null)
			fontName = "SansSerif";
		fontStyle = getParameter("fontStyle");
		if (fontStyle == null)
			fontStyleInt = 1;
		else
			fontStyleInt = Integer.parseInt(fontStyle);
		fontSize = getParameter("fontSize");
		if (fontSize == null)
			fontSizeInt = 12;
		else
			fontSizeInt = Integer.parseInt(fontSize);

		// set colors
		bcString = getParameter("buttonColor");
		if (bcString == null)
			buttonColor = new Color (0);
		else
			buttonColor = new Color (Integer.parseInt(bcString));
		fcString = getParameter("fontColor");
		if (fcString == null)
			fontColor = new Color (16777215);
		else
			fontColor = new Color (Integer.parseInt(fcString));


		this.setLayout(new GridLayout(rows, 1));
		for (int i = 0; i < rows; i++) {

			// read each row and tokenize
			StringTokenizer reader = new StringTokenizer (getParameter("menu" + i),",");
			urlArray[i] = new String[reader.countTokens()];

			// create row buttons and add them
			button[i] = new Button (reader.nextToken());
			button[i].setFont(new Font (fontName, fontStyleInt, fontSizeInt));
			button[i].setBackground(buttonColor);
			button[i].setForeground(fontColor);
			this.add(button[i]);
			button[i].addActionListener(this);

			// read in target frame
			target[i] = reader.nextToken();

			// populate display list and url array
			list[i] = new List();
			while (reader.hasMoreTokens()) {
				list[i].addItem(reader.nextToken());
				urlArray[i][token++] = reader.nextToken();
			}
			list[i].addItemListener(this);
			token = 0;
		}
	}

	// calculate dimensions
	public void start() {
		if (startSwitch) {
			largeButtonSize = button[0].getSize();
			smallButtonHeight = (int)(largeButtonSize.height / 1.4);
			listHeightSize = (largeButtonSize.height * rows) - (smallButtonHeight * rows);
			startSwitch = false;
		} else {
			this.removeAll();
			for (int i = 0; i < rows; i++) {
				this.add(button[i]);
			}
			prevSource = null;
		}
	}

	// detect button actions
	public void actionPerformed(ActionEvent evt) {
		int currentHeightSize = 0;
		boolean oneElementList = false;

		Object source = evt.getSource();
		// remove previous list
		if (prevList != null)
			prevList.setVisible(false);

		// check for one element list
		for (int i = 0; i < rows; i++) {
			if (source == button[i] && list[i].getItemCount() == 1) {
				// move to large button size
				if (!largeButtonSize.equals(button[0].getSize())) {
					for (int j = 0; j < rows; j++) {
						button[j].setBounds(0, currentHeightSize, largeButtonSize.width, largeButtonSize.height);
						currentHeightSize += largeButtonSize.height;
					}
				}
				oneElementList = true;
				try {
					AppletContext context = getAppletContext();
					URL u = new URL(urlArray[i][0]);
					context.showDocument(u, target[i]);
				}
				catch(Exception e) {
					showStatus("Error " + e);
				}
				break;
			}
		}

		if (!oneElementList) {
			// if the menu is in a expanded state
			if (prevSource == source) {
				for (int i = 0; i < rows; i++) {
					button[i].setBounds(0, currentHeightSize, largeButtonSize.width, largeButtonSize.height);
					currentHeightSize += largeButtonSize.height;
				}
				prevSource = null;
			}
			// else move to the expanded state
			else {
				prevSource = source;
				for (int i = 0; i < rows; i++) {
					button[i].setBounds(0, currentHeightSize, largeButtonSize.width, smallButtonHeight);
					currentHeightSize += smallButtonHeight;
					if (source == button[i]) {
						prevList = list[i];
						this.add(list[i]);
						list[i].setBounds(0, currentHeightSize, largeButtonSize.width, listHeightSize);
						list[i].setVisible(true);
						currentHeightSize += listHeightSize;
					}
				}
			}
		}
	}

	// detect list actions
	public void itemStateChanged(ItemEvent evt) {

		List source = (List) evt.getSource();
		int listIndex = source.getSelectedIndex();
		// if item selected go to corresponding url
		if (evt.getStateChange() == ItemEvent.SELECTED) {
			for (int i = 0; i < rows; i++) {
				if (source == list[i]) {
					try {
						AppletContext context = getAppletContext();
						URL u = new URL(urlArray[i][listIndex]);
						context.showDocument(u, target[i]);
					}
					catch(Exception e) {
						showStatus("Error " + e);
					}
					break;
				}
			}
		}
	}
}
